//
//  TableViewCell2.swift
//  SideMenu
//
//  Created by Rahul on 19/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import UIKit

class TableViewCell2: UITableViewCell {
    
    @IBOutlet weak var feb11Lbl: UILabel!
    
    
    @IBOutlet weak var descriptionLbl: UILabel!
    
    
    @IBOutlet weak var announmentImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
