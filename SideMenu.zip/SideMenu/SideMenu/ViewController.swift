//
//  ViewController.swift
//  SideMenu
//
//  Created by Rahul on 19/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var arrdata = ["Overview","Products","Orders","Reports","Settings","Adminstration","Maintenance","Help"]
    
    var arrimg = ["overview","products","tag","reports","settings","Adminstration","maintenance","help"]
    
        @IBOutlet weak var sideview: UIView!
    
    @IBOutlet weak var sidebar: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrdata.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        cell.img.image = UIImage(named: arrimg[indexPath.row])
            cell.lbl.text = arrdata[indexPath.row]
        return cell
        
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
      
        
    }
    
    @IBAction func menubutton(_ sender: Any) {
        
        
          let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let viewController2 = storyBoard.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
        self.present(viewController2,animated: true,completion: nil)
        
        
        
    }
    
  
}
