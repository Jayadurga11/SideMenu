//
//  ViewController2.swift
//  SideMenu
//
//  Created by Rahul on 19/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    
    var labels = [Adata]()
    
  
    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var label2: UILabel!
    
    
    @IBOutlet weak var promotionsLbl: UILabel!
    
    
    @IBOutlet weak var viewpromotions: UIView!
    
    
    @IBOutlet weak var catalog: UILabel!
    
    
    @IBOutlet weak var viewcatalog: UIView!
    
    
    @IBOutlet weak var announcements: UILabel!
    
    
    @IBOutlet weak var thisweekLbl: UILabel!
    
    @IBOutlet weak var serach1: UISearchBar!
    
    @IBOutlet weak var tableview2: UITableView!
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let label1 = Adata(ALabel: "feb11", ADescription: "Update to API endpoint limit", AImage: "Vector (1)")
        labels.append(label1)
        
        
        let label2 = Adata(ALabel: "feb11", ADescription: "Covid-19 Impact on Your Operations", AImage: "Vector (1)")
        labels.append(label2)
        
        let label3 = Adata(ALabel: "feb11", ADescription: "API endpoint limit forward", AImage: "Vector (1)")
        labels.append(label3)
        
    
    }
    

    @IBAction func menubar(_ sender: Any) {
        
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                   let viewController = storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
               self.present(viewController,animated: true,completion: nil)
    
    }
    
    
    @IBAction func serachbar(_ sender: Any) {
    }
    
    @IBAction func bellicon(_ sender: Any) {
    }
    
    @IBAction func userBtn(_ sender: Any) {
    }
    
    @IBAction func menuBtn2(_ sender: Any) {
    }
    
    
}
extension ViewController2: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return labels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview2.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell2
        
        cell.descriptionLbl.text = labels[indexPath.row].Description
        cell.feb11Lbl.text = labels[indexPath.row].Label
        cell.announmentImage.image = UIImage(named: labels[indexPath.row].Image)
        return cell
    }
    
    
}
