//
//  Adata.swift
//  SideMenu
//
//  Created by Rahul on 19/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import Foundation

class Adata {
    
    
       var Label:String
       var Description:String
       var Image:String
    
     init(ALabel: String,ADescription: String,AImage: String) {
           
           Label = ALabel
           Description = ADescription
           Image = AImage
           
    
    }
    
}
